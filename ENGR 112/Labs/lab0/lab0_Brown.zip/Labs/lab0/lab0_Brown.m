%Lab 0 Andrew Brown
clear
clc
% I am practicing making plots and printing.

%asigning variable
xs=linspace(0,pi);
ys=linspace(0,100);

plot(xs,ys)

%practicing printing strings
fprintf('I made a line!\n')
